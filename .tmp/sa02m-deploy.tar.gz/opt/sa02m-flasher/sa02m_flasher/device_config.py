# -*- coding: utf-8 -*-
"""
Снимки и запись настроек устройств для веб-окон конфигурации.

Поддерживаются:
  - линейка MP/MR-02m: сведения + сеть;
  - DTV / Sens.: живые данные, профильные настройки, сеть;
  - CE-02m-3: живые данные, ТТ/фазы, сеть.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional, Tuple

from . import dtv_registers
from .flash_protocol import FlasherProtocol
from .modbus_io import (
    coil_bits_from_payload,
    decode_bootloader_version_registers_8,
    decode_signature_from_holding_290_payload,
    make_serial_send_rtu_persistent,
    parse_regs_be_u16,
    read_coils,
    read_holding,
    read_input_regs,
    uint32_from_modbus_reg_pair_be,
    write_coil,
    write_multiple,
    write_single,
)
from . import module_profiles

REG_SERIAL_LO = 270
REG_SIGNATURE = 290
REG_SIGNATURE_COUNT = 12
REG_APP_VERSION = 320
REG_APP_VERSION_COUNT = 4
REG_BOOTLOADER_VER = 330
REG_BOOTLOADER_VER_COUNT = 8

REG_NET_BAUD = 110
REG_NET_PARITY = 111
REG_NET_STOP = 112
REG_FAST_MODBUS = 122
REG_NET_ADDR = 128

CE_INPUT_START = 500
CE_INPUT_COUNT = 48
CE_CFG_START = 553
CE_CFG_COUNT = 7

PARITY_CHAR_TO_REG = {"N": 0, "O": 1, "E": 2}
PARITY_REG_TO_CHAR = {v: k for k, v in PARITY_CHAR_TO_REG.items()}
ALLOWED_BAUD_REG_CODES = (12, 24, 48, 96, 192, 384, 576, 1152)


def _normalize_parity(parity: Any) -> str:
    p = str(parity or "N").strip().upper()[:1]
    return p if p in PARITY_CHAR_TO_REG else "N"


def _device_slave(device: Dict[str, Any]) -> int:
    addr = int(device.get("address") or 0) & 0xFFFF
    if not 1 <= addr <= 247:
        raise ValueError("Недопустимый Modbus-адрес устройства")
    return addr


def _device_line(device: Dict[str, Any]) -> Tuple[int, str, int]:
    baud = int(device.get("baudrate") or 0)
    if baud <= 0:
        raise ValueError("Недопустимая скорость устройства")
    stop = int(device.get("stopbits") or 1)
    if stop not in (1, 2):
        stop = 1
    return baud, _normalize_parity(device.get("parity")), stop


def _open_transport(device_path: str, device: Dict[str, Any]):
    baud, parity, stop = _device_line(device)
    return make_serial_send_rtu_persistent(
        device_path,
        baud,
        parity,
        stop,
        default_timeout_ms=700,
        pre_open_delay_s=0.02,
    )


def _read_u16(send, slave: int, reg: int, timeout_ms: int = 700) -> Optional[int]:
    payload, err = read_holding(send, slave, reg, 1, timeout_ms)
    if err or not payload:
        return None
    regs = parse_regs_be_u16(payload)
    return int(regs[0]) & 0xFFFF if regs else None


def _read_regs(send, slave: int, start: int, count: int, *, input_regs: bool = False, timeout_ms: int = 900) -> List[int]:
    reader = read_input_regs if input_regs else read_holding
    payload, err = reader(send, slave, start, count, timeout_ms)
    if err or not payload:
        return []
    return parse_regs_be_u16(payload)


def _read_live_identity(send, slave: int, fallback: Dict[str, Any]) -> Dict[str, Any]:
    signature = ""
    serial = int(fallback.get("serial") or 0) & 0xFFFFFFFF
    app_version = str(fallback.get("app_version") or "—").strip() or "—"
    bl_version = str(fallback.get("bootloader_version") or "—").strip() or "—"
    type_code = None

    pl_sig, err_sig = read_holding(send, slave, REG_SIGNATURE, REG_SIGNATURE_COUNT, 900)
    if not err_sig and pl_sig:
        signature = decode_signature_from_holding_290_payload(pl_sig).strip()

    pl_ser, err_ser = read_holding(send, slave, REG_SERIAL_LO, 2, 900)
    if not err_ser and pl_ser:
        serial = uint32_from_modbus_reg_pair_be(pl_ser, 0)

    pl_ver, err_ver = read_holding(send, slave, REG_APP_VERSION, REG_APP_VERSION_COUNT, 900)
    if not err_ver and pl_ver:
        parsed = FlasherProtocol.parse_app_version_from_holding_payload(pl_ver)
        if parsed:
            app_version = parsed

    pl_bl, err_bl = read_holding(send, slave, REG_BOOTLOADER_VER, REG_BOOTLOADER_VER_COUNT, 900)
    if not err_bl and pl_bl:
        parsed_bl = decode_bootloader_version_registers_8(pl_bl)
        if parsed_bl:
            bl_version = parsed_bl

    regs0 = _read_regs(send, slave, 0, 1, input_regs=True, timeout_ms=500)
    if regs0:
        type_code = int(regs0[0]) & 0xFFFF
    elif not regs0:
        hold0 = _read_regs(send, slave, 0, 1, input_regs=False, timeout_ms=500)
        if hold0:
            type_code = int(hold0[0]) & 0xFFFF

    return {
        "signature": signature or str(fallback.get("signature") or "").strip(),
        "serial": serial,
        "app_version": app_version,
        "bootloader_version": bl_version,
        "type_code": type_code,
    }


def _kind_from_identity(signature: str, type_code: Optional[int]) -> Optional[str]:
    sig = str(signature or "").strip()
    sig_code = module_profiles.code_from_signature(sig)
    if sig_code == module_profiles.DTV:
        return "dtv"
    if sig_code == module_profiles.MP02_CE02M3 or type_code == module_profiles.MP02_CE02M3:
        return "ce"
    if module_profiles.is_mp_module_signature_for_batch_flash(sig):
        return "mr"
    return None


def _read_network(send, slave: int, fallback_device: Dict[str, Any]) -> Dict[str, Any]:
    regs_110 = _read_regs(send, slave, REG_NET_BAUD, 3, timeout_ms=800)
    addr_u16 = _read_u16(send, slave, REG_NET_ADDR, 800)
    fast_u16 = _read_u16(send, slave, REG_FAST_MODBUS, 800)

    if len(regs_110) >= 3:
        baud = int(regs_110[0]) * 100
        parity = PARITY_REG_TO_CHAR.get(int(regs_110[1]) & 0xFFFF, "N")
        stop = int(regs_110[2]) & 0xFFFF
    else:
        baud, parity, stop = _device_line(fallback_device)
    if stop not in (1, 2):
        stop = 1
    if baud <= 0:
        baud = int(fallback_device.get("baudrate") or 9600)

    return {
        "baudrate": baud,
        "parity": parity,
        "stopbits": stop,
        "address": int(addr_u16 or fallback_device.get("address") or 1) & 0xFFFF,
        "fast_modbus": bool(fast_u16) if fast_u16 is not None else False,
    }


def _read_ce_snapshot(send, slave: int) -> Dict[str, Any]:
    regs = _read_regs(send, slave, CE_INPUT_START, CE_INPUT_COUNT, input_regs=True, timeout_ms=1100)
    if len(regs) < CE_INPUT_COUNT:
        regs = list(regs) + [0] * (CE_INPUT_COUNT - len(regs))

    def _s16(v: int) -> int:
        return v - 0x10000 if v >= 0x8000 else v

    def _i32(lo: int, hi: int) -> int:
        v = ((hi & 0xFFFF) << 16) | (lo & 0xFFFF)
        return v - 0x100000000 if v >= 0x80000000 else v

    cfg = _read_regs(send, slave, CE_CFG_START, CE_CFG_COUNT, input_regs=False, timeout_ms=1000)
    while len(cfg) < CE_CFG_COUNT:
        cfg.append(0)

    return {
        "live": {
            "ua": regs[0] / 10.0,
            "ub": regs[1] / 10.0,
            "uc": regs[2] / 10.0,
            "uab": regs[6] / 10.0,
            "ubc": regs[7] / 10.0,
            "uca": regs[8] / 10.0,
            "ia": regs[10] / 1000.0,
            "ib": regs[11] / 1000.0,
            "ic": regs[12] / 1000.0,
            "in": regs[13] / 1000.0,
            "pa": _i32(regs[18], regs[19]),
            "pb": _i32(regs[20], regs[21]),
            "pc": _i32(regs[22], regs[23]),
            "pt": _i32(regs[24], regs[25]),
            "qa": _i32(regs[26], regs[27]),
            "qb": _i32(regs[28], regs[29]),
            "qc": _i32(regs[30], regs[31]),
            "qt": _i32(regs[32], regs[33]),
            "sa": _i32(regs[34], regs[35]),
            "sb": _i32(regs[36], regs[37]),
            "sc": _i32(regs[38], regs[39]),
            "st": _i32(regs[40], regs[41]),
            "freq": regs[42] / 100.0,
            "cfa": _s16(regs[43]) / 1000.0,
            "cfb": _s16(regs[44]) / 1000.0,
            "cfc": _s16(regs[45]) / 1000.0,
            "cft": _s16(regs[46]) / 1000.0,
            "tasic": _s16(regs[47]),
        },
        "config": {
            "ph_loss": int(cfg[0]) & 0xFFFF,
            "inv_a": int(cfg[1]) & 0xFFFF,
            "inv_b": int(cfg[2]) & 0xFFFF,
            "inv_c": int(cfg[3]) & 0xFFFF,
            "kt_a": int(cfg[4]) & 0xFFFF,
            "kt_b": int(cfg[5]) & 0xFFFF,
            "kt_c": int(cfg[6]) & 0xFFFF,
        },
    }


def _read_dtv_snapshot(send, slave: int) -> Dict[str, Any]:
    regs = _read_regs(
        send,
        slave,
        dtv_registers.DTV_INPUT_LIVE_START,
        dtv_registers.DTV_INPUT_LIVE_COUNT,
        input_regs=True,
        timeout_ms=1100,
    )
    while len(regs) < dtv_registers.DTV_INPUT_LIVE_COUNT:
        regs.append(0)

    def _s16_tenths(v: int) -> float:
        return float(dtv_registers.dtv_u16_to_s16(v)) / 10.0

    eco2_ppm = float(int(regs[20]) & 0xFFFF) / 2.0
    calib_regs = _read_regs(send, slave, 31, 9, input_regs=False, timeout_ms=1000)
    while len(calib_regs) < 9:
        calib_regs.append(0)
    mov_avg = _read_regs(
        send,
        slave,
        dtv_registers.DTV_MOV_AVG_HOLDING_ANCHOR,
        dtv_registers.DTV_MOV_AVG_HOLDING_SPAN,
        input_regs=False,
        timeout_ms=1100,
    )
    ext_sel = _read_u16(send, slave, dtv_registers.DTV_HOLDING_EXT_TEMP_SELECT, 800)
    pres_delay = _read_u16(send, slave, dtv_registers.DTV_HOLDING_PRESENCE_OFF_DELAY, 800)

    coils_payload, coils_err = read_coils(
        send,
        slave,
        dtv_registers.DTV_COIL_BUZZER,
        2,
        1000,
    )
    coil_bits = coil_bits_from_payload(coils_payload or b"", 2) if not coils_err else [False, False]

    moving_average_depths: List[int] = []
    for slot in range(dtv_registers.DTV_MOV_AVG_SLOT_COUNT):
        idx = 3 * slot + 1
        raw = int(mov_avg[idx]) if idx < len(mov_avg) else dtv_registers.DTV_MOV_AVG_DEPTH_MIN
        moving_average_depths.append(
            max(dtv_registers.DTV_MOV_AVG_DEPTH_MIN, min(dtv_registers.DTV_MOV_AVG_DEPTH_MAX, raw))
        )

    return {
        "live": {
            "t_ds": _s16_tenths(regs[0]),
            "t_mcp": _s16_tenths(regs[1]),
            "t_hdc": _s16_tenths(regs[2]),
            "t_bme280": _s16_tenths(regs[3]),
            "t_bme680": _s16_tenths(regs[4]),
            "t_ext": _s16_tenths(regs[5]),
            "h_hdc": regs[6] / 10.0,
            "h_bme280": regs[7] / 10.0,
            "h_bme680": regs[8] / 10.0,
            "p_bme280_mmhg": dtv_registers.dtv_u16_to_s16(regs[9]),
            "p_bme680_mmhg": dtv_registers.dtv_u16_to_s16(regs[10]),
            "p_bme280_kpa": dtv_registers.dtv_u16_to_s16(regs[11]) / 100.0,
            "p_bme680_kpa": dtv_registers.dtv_u16_to_s16(regs[12]) / 100.0,
            "alt_bme280": dtv_registers.dtv_u16_to_s16(regs[13]),
            "alt_bme680": dtv_registers.dtv_u16_to_s16(regs[14]),
            "voc": int(regs[15]) & 0xFFFF,
            "iaq_bme": int(regs[16]) & 0xFFFF,
            "co2_bme": int(regs[17]) & 0xFFFF,
            "tvoc_z": int(regs[18]) & 0xFFFF,
            "iaq_z": int(regs[19]) & 0xFFFF,
            "eco2_z": eco2_ppm,
            "etoh_z": int(regs[21]) & 0xFFFF,
            "light": int(regs[24]) & 0xFFFF,
            "presence": int(regs[25]) & 0xFFFF,
            "presence_ld2412": int(regs[26]) & 0xFFFF,
            "ld_dist_mov": int(regs[27]) & 0xFFFF,
            "ld_dist_still": int(regs[28]) & 0xFFFF,
            "ld_dist": int(regs[29]) & 0xFFFF,
        },
        "settings": {
            "ext_temp_select": 1 if int(ext_sel or 0) == 1 else 0,
            "presence_off_delay": int(pres_delay or 0),
            "buzzer_on": bool(coil_bits[0]) if coil_bits else False,
            "leds_on": bool(coil_bits[1]) if len(coil_bits) > 1 else False,
            "calibration_offsets": [
                dtv_registers.dtv_u16_to_s16(v & 0xFFFF)
                for v in calib_regs[:9]
            ],
            "moving_average_depths": moving_average_depths,
        },
    }


def snapshot_for_device(device_path: str, device: Dict[str, Any]) -> Dict[str, Any]:
    send, close_transport = _open_transport(device_path, device)
    try:
        slave = _device_slave(device)
        identity = _read_live_identity(send, slave, device)
        kind = _kind_from_identity(identity["signature"], identity["type_code"])
        if kind is None:
            raise ValueError("Окно настройки доступно только для устройств нашей линейки")

        network = _read_network(send, slave, device)
        payload: Dict[str, Any] = {
            "kind": kind,
            "info": {
                "address": network["address"],
                "serial": int(identity["serial"]) & 0xFFFFFFFF,
                "signature": identity["signature"] or str(device.get("signature") or ""),
                "app_version": identity["app_version"],
                "bootloader_version": identity["bootloader_version"],
                "type_code": identity["type_code"],
                "line": {
                    "baudrate": network["baudrate"],
                    "parity": network["parity"],
                    "stopbits": network["stopbits"],
                },
            },
            "network": network,
        }
        if kind == "ce":
            payload["ce"] = _read_ce_snapshot(send, slave)
        elif kind == "dtv":
            payload["dtv"] = _read_dtv_snapshot(send, slave)
        return payload
    finally:
        close_transport()


def apply_network_settings(
    device_path: str,
    device: Dict[str, Any],
    network: Dict[str, Any],
) -> Dict[str, Any]:
    baud = int(network.get("baudrate") or 0)
    baud_reg = baud // 100
    if baud_reg not in ALLOWED_BAUD_REG_CODES:
        raise ValueError("Скорость линии вне допустимого диапазона")
    parity = _normalize_parity(network.get("parity"))
    stopbits = int(network.get("stopbits") or 1)
    if stopbits not in (1, 2):
        raise ValueError("Стоп-биты: только 1 или 2")
    address = int(network.get("address") or 0)
    if not 1 <= address <= 247:
        raise ValueError("Modbus-адрес: только 1..247")
    want_fast = bool(network.get("fast_modbus"))

    send, close_transport = _open_transport(device_path, device)
    try:
        slave = _device_slave(device)
        current = _read_network(send, slave, device)
        current_fast = bool(current.get("fast_modbus"))
        if current["address"] != address:
            err = write_multiple(send, slave, REG_NET_ADDR, [address & 0xFFFF], 900)
            if err:
                raise RuntimeError(f"Запись рег. 128: {err}")
            slave = address

        if want_fast and not current_fast:
            err = write_single(send, slave, REG_FAST_MODBUS, 1, 800)
            if err:
                raise RuntimeError(f"Запись рег. 122: {err}")

        line_changed = (
            int(current.get("baudrate") or 0) != baud
            or str(current.get("parity") or "N") != parity
            or int(current.get("stopbits") or 1) != stopbits
        )
        if line_changed:
            err = write_multiple(
                send,
                slave,
                REG_NET_BAUD,
                [baud_reg & 0xFFFF, PARITY_CHAR_TO_REG[parity], stopbits & 0xFFFF],
                1200,
            )
            if err:
                raise RuntimeError(f"Запись рег. 110-112: {err}")
            if int(current.get("baudrate") or 0) != baud:
                time.sleep(0.40)

        if (not want_fast) and current_fast:
            err = write_single(send, slave, REG_FAST_MODBUS, 0, 800)
            if err:
                raise RuntimeError(f"Запись рег. 122: {err}")
    finally:
        close_transport()

    updated_device = dict(device)
    updated_device.update(
        {
            "address": address,
            "baudrate": baud,
            "parity": parity,
            "stopbits": stopbits,
        }
    )
    return snapshot_for_device(device_path, updated_device)


def write_allowed_holding(
    device_path: str,
    device: Dict[str, Any],
    reg: int,
    value: int,
) -> Dict[str, Any]:
    send, close_transport = _open_transport(device_path, device)
    try:
        slave = _device_slave(device)
        identity = _read_live_identity(send, slave, device)
        kind = _kind_from_identity(identity["signature"], identity["type_code"])
        allowed_regs: set[int] = set()
        if kind == "dtv":
            allowed_regs.update({dtv_registers.DTV_HOLDING_EXT_TEMP_SELECT, dtv_registers.DTV_HOLDING_PRESENCE_OFF_DELAY})
            allowed_regs.update(range(31, 40))
            allowed_regs.update(dtv_registers.DTV_MOV_AVG_DEPTH_REGS)
        elif kind == "ce":
            allowed_regs.update(range(553, 560))
        if reg not in allowed_regs:
            raise ValueError("Запись этого регистра через веб-окно не разрешена")
        err = write_single(send, slave, reg, int(value) & 0xFFFF, 1000)
        if err:
            raise RuntimeError(f"Запись рег. {reg}: {err}")
    finally:
        close_transport()
    return snapshot_for_device(device_path, device)


def write_allowed_coil(
    device_path: str,
    device: Dict[str, Any],
    coil: int,
    on: bool,
) -> Dict[str, Any]:
    send, close_transport = _open_transport(device_path, device)
    try:
        slave = _device_slave(device)
        identity = _read_live_identity(send, slave, device)
        kind = _kind_from_identity(identity["signature"], identity["type_code"])
        if kind != "dtv" or coil not in (dtv_registers.DTV_COIL_BUZZER, dtv_registers.DTV_COIL_LEDS_ALL):
            raise ValueError("Запись этой катушки через веб-окно не разрешена")
        err = write_coil(send, slave, coil, bool(on), 1000)
        if err:
            raise RuntimeError(f"Запись coil {coil}: {err}")
    finally:
        close_transport()
    return snapshot_for_device(device_path, device)
